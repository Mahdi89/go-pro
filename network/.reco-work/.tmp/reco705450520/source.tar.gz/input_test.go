package main

import (
	"math"
	"testing"

	"github.com/ReconfigureIO/fixed"
	"github.com/ReconfigureIO/fixed/host"
)

/*
func TestStocWalk(t *testing.T) {

	// Parameters
	p := Param{
		s0:         host.I26Float64(114.64),    // Actual price
		drift:      host.I26Float64(0.0016273), // Drft term (daily)
		volatility: host.I26Float64(0.088864),  // Volatility (daily)
		k:          host.I26Float64(100),       // Strike price
		days:       uint32(252),                  // Days until option expiration
	}

	// Computed using the python implementation
	expected := Ret{
		avg:         host.I26Float64(18.264974286671009),
		zero_trials: uint32(0),
	}

	p.seeds = rand.Uint32()
	result := StocWalk(p)

	err := math.Abs((float64(expected.avg)/float64(1<<6))-(float64(result.avg)/float64(1<<6))) / (float64(expected.avg) / float64(1<<6))

	// Error if >10%
	if err > 0.1 || expected.zero_trials != result.zero_trials {
		t.Errorf("Expected price %f got %f", float64(expected.avg)/float64(1<<6), float64(result.avg)/float64(1<<6))
		t.Errorf("Expected zero trials %d got %d", expected.zero_trials, result.zero_trials)

	}
}*/

func TestMapReduce(t *testing.T) {
	// Initialize the reducer.empty
	ret := RetInit()

	t_ := float64(365)   // Total periods in a year
	r := float64(0.033)  // Risk free rate (yearly)
	N := float64(100000) // Number of Monte Carlo trials

	// Parameters
	p := Param{
		s0:         host.I26Float64(114.64),    // Actual price
		drift:      host.I26Float64(0.0016273), // Drft term (daily)
		volatility: host.I26Float64(0.088864),  // Volatility (daily)
		k:          host.I26Float64(100),       // Strike price
		days:       2,                          // Days until option expiration
	}

	rands := make(chan fixed.Int26_6)
	go Rands(123, rands)

	// Simulation loop
	for i := 0; i < int(N); i++ {
		ret = Payoff(ret, StocWalk(rands, p))
	}
	// Finalize the price calculation
	avg := float64(ret.avg) / float64(1<<6)
	days := float64(p.days)
	ret.avg = host.I26Float64((avg * math.Exp(-r/t_*days)) / N)

	// Calculated using the original python code
	expected := Ret{
		avg:         host.I26Float64(16.064522771),
		zero_trials: uint32(14771),
	}

	err_avg := math.Abs((float64(expected.avg)/float64(1<<6))-(float64(ret.avg)/float64(1<<6))) / (float64(expected.avg) / float64(1<<6))
	err_trials := math.Abs(float64(expected.zero_trials-ret.zero_trials)) / float64(expected.zero_trials)

	// Error if >10%
	if err_avg > 0.1 || err_trials > 0.2 {
		t.Errorf("Expected price %f got %f", float64(expected.avg)/float64(1<<6), float64(ret.avg)/float64(1<<6))
		t.Errorf("Expected zero trials %d got %d", expected.zero_trials, ret.zero_trials)

	}
}

func BenchmarkMapReduce(b *testing.B) {
	// run the simulation function b.N times

	// Initialize the reducer.empty
	ret := RetInit()

	rands := make(chan fixed.Int26_6)
	go Rands(123, rands)
	// Parameters
	p := Param{
		s0:         host.I26Float64(114.64),    // Actual price
		drift:      host.I26Float64(0.0016273), // Drft term (daily)
		volatility: host.I26Float64(0.088864),  // Volatility (daily)
		k:          host.I26Float64(100),       // Strike price
		days:       2,                          // Days until option expiration
	}

	for n := 0; n < b.N; n++ {
		ret = Payoff(ret, StocWalk(rands, p))
	}
}
