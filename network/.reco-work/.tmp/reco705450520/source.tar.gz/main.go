package main

import (
	// Import the entire framework
	_ "github.com/ReconfigureIO/sdaccel"
	arbitrate "github.com/ReconfigureIO/sdaccel/axi/arbitrate"
	aximemory "github.com/ReconfigureIO/sdaccel/axi/memory"
	axiprotocol "github.com/ReconfigureIO/sdaccel/axi/protocol"
)

func Deserialize(inputChan <-chan uint32, outputChan chan<- uint32) {
	for {
		outputChan <- <-inputChan
	}
}

func Serialize(inputChan <-chan uint32, outputChan chan<- uint32) {
	for {
		outputChan <- uint32(0)
		outputChan <- uint32(0)
	}
}

func Processor(){


}

func Router(){

}

func Top(
	inputData uintptr,
	outputData uintptr,
	length uint32,
	// The second set of arguments will be the ports for interacting with memory
	memReadAddr chan<- axiprotocol.Addr,
	memReadData <-chan axiprotocol.ReadData,

	memWriteAddr chan<- axiprotocol.Addr,
	memWriteData chan<- axiprotocol.WriteData,
	memWriteResp <-chan axiprotocol.WriteResp) {

	// Read all of the input data into a channel
	inputChan := make(chan uint32, 4)

	go aximemory.ReadBurstUInt32(
		memReadAddr, memReadData, true, inputData, length*(32/32), inputChan)

	// Read all of the input data into a channel
	elementChan := make(chan uint32, 1)
	go Deserialize(inputChan, elementChan)

	// Read all of the input data into a channel
	// dataChan := make(chan [4]uint32, 1)

	data0 := make(chan uint32, 1)

	data1 := make(chan uint32, 1)

	data2 := make(chan uint32, 1)

	data3 := make(chan uint32, 1)

	interConnect0 := make(chan uint32, 1)

	interConnect1 := make(chan uint32, 1)

	interConnect2 := make(chan uint32, 1)

	interConnect3 := make(chan uint32, 1)

	// Processor part

	go func() {
		for {
			Processor(<-data0)
		}
	}()

	go func() {
		for {
			Processor(<-data1)
		}
	}()

	go func() {
		for {
			Processor(<-data2)
		}
	}()

	go func() {
		for {
			Processor(<-data3)
		}
	}()

	// Network part

	go func() {
		for {
			Router(<-data0, interConnect0, interConnect0)
		}
	}()

	go func() {
		for {
			Router(<-data1, interConnect1, interConnect1)
		}
	}()

	go func() {
		for {
			Router(<-data2, interConnect2, interConnect2)
		}
	}()

	go func() {
		for {
			Router(<-data3, interConnect3, interConnect3)
		}
	}()

	outputDataChan := make(chan uint32)
	go Serialize(interConnect0, outputDataChan)

	// Write it back to the pointer the host requests
	aximemory.WriteBurstUInt32(
		memWriteAddr, memWriteData, memWriteResp, true, outputData, 32/32, outputDataChan)
}

func Benchmark(n uint) {
	ra := make(chan axiprotocol.Addr)
	rd := make(chan axiprotocol.ReadData)

	wa := make(chan axiprotocol.Addr)
	wd := make(chan axiprotocol.WriteData)
	wr := make(chan axiprotocol.WriteResp)

	go func() {
		for {
			a := <-ra
			for i := a.Len; i != 255; i-- {
				rd <- axiprotocol.ReadData{Last: i == 0}
			}
		}
	}()

	go func() {
		for {
			<-wa
			running := true
			for running {
				d := <-wd
				running = !d.Last
			}
			wr <- axiprotocol.WriteResp{}
		}
	}()

	Top(0, 0, uint32(n), ra, rd, wa, wd, wr)
}
