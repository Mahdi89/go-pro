package main

func Deserialize(inputChan <-chan uint32, outputChan chan<- uint32) {
	for {
		outputChan <- <-inputChan
	}
}

func Serialize(inputChan <-chan uint32, outputChan chan<- uint32) {
	for {
		outputChan <- uint32(0)
		outputChan <- uint32(0)
	}
}

func Processor(){


}

func Router(){

}
